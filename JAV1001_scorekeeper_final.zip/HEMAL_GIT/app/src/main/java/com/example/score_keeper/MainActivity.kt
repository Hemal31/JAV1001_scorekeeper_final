package com.example.score_keeper

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SwitchCompat

class MainActivity : AppCompatActivity() {

    private lateinit var aSwitch: SwitchCompat
    private lateinit var team1Score: TextView
    private lateinit var team2Score: TextView
    private lateinit var incTeam1: Button
    private lateinit var decTeam1: Button
    private lateinit var incTeam2: Button
    private lateinit var decTeam2: Button
    private lateinit var radioGroup: RadioGroup
    private lateinit var radioButton: RadioButton
    private var team1 = 0
    private var team2 = 0
    private var t1: String = ""
    private var t2: String = ""

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.score_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.about -> {
                Toast.makeText(
                    this,
                    "Created by Parthiv Patel\nStudent Id: A00226243\nCourse code: IOT-1009",
                    Toast.LENGTH_LONG
                ).show()
                return true
            }
            R.id.settings -> {
                val myIntent = Intent(this@MainActivity, NewSettings::class.java)
                startActivity(myIntent)
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    class NewSettings {

    }

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        if (AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES) {
            setTheme(R.style.DarkTheme)
        } else {
            setTheme(R.style.AppTheme)
        }

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        aSwitch = findViewById(R.id.mode)
        team1Score = findViewById(R.id.t1_score)
        team2Score = findViewById(R.id.t2_score)
        incTeam1 = findViewById(R.id.inc_team1)
        decTeam1 = findViewById(R.id.dec_team1)
        incTeam2 = findViewById(R.id.inc_team2)
        decTeam2 = findViewById(R.id.dec_team2)
        radioGroup = findViewById(R.id.radio_group)

        if (AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES) {
            aSwitch.isChecked = true
        }

        aSwitch.setOnCheckedChangeListener { _, isChecked ->
            AppCompatDelegate.setDefaultNightMode(
                if (isChecked) AppCompatDelegate.MODE_NIGHT_YES
                else AppCompatDelegate.MODE_NIGHT_NO
            )
        }

        incTeam1.setOnClickListener {
            val id = radioGroup.checkedRadioButtonId
            radioButton = findViewById(id)
            when (id) {
                R.id.radioButton1 -> {
                    team1++
                    t1 = team1.toString()
                    team1Score.text = t1
                }
                R.id.radioButton2 -> {
                    team1 += 2
                    t1 = team1.toString()
                    team1Score.text = t1
                }
                R.id.radioButton3 -> {
                    team1 += 3
                    t1 = team1.toString()
                    team1Score.text = t1
                }
            }
        }

        decTeam1.setOnClickListener {
            val id = radioGroup.checkedRadioButtonId
            radioButton = findViewById(id)
            when (id) {
                R.id.radioButton1 -> {
                    team1--
                    t1 = team1.toString()
                    team1Score.text = t1
                }
                R.id.radioButton2 -> {
                    team1 -= 2
                    t1 = team1.toString()
                    team1Score.text = t1
                }
                R.id.radioButton3 -> {
                    team1 -= 3
                    t1 = team1.toString()
                    team1Score.text = t1
                }
            }
        }

        incTeam2.setOnClickListener {
            val id = radioGroup.checkedRadioButtonId
            radioButton = findViewById(id)
            when (id) {
                R.id.radioButton1 -> {
                    team2++
                    t2 = team2.toString()
                    team2Score.text = t2
                }
                R.id.radioButton2 -> {
                    team2 += 2
                    t2 = team2.toString()
                    team2Score.text = t2
                }
                R.id.radioButton3 -> {
                    team2 += 3
                    t2 = team2.toString()
                    team2Score.text = t2
                }
            }
        }

        decTeam2.setOnClickListener {
            val id = radioGroup.checkedRadioButtonId
            radioButton = findViewById(id)
            when (id) {
                R.id.radioButton1 -> {
                    team2--
                    t2 = team2.toString()
                    team2Score.text = t2
                }
                R.id.radioButton2 -> {
                    team2 -= 2
                    t2 = team2.toString()
                    team2Score.text = t2
                }
                R.id.radioButton3 -> {
                    team2 -= 3
                    t2 = team2.toString()
                    team2Score.text = t2
                }
            }
        }
    }
}


